//
//  heuristic.hpp
//  AIhomework1
//
//  Created by 刘驭壬 on 2017/10/9.
//  Copyright © 2017年 刘驭壬. All rights reserved.
//

#ifndef heuristic_hpp
#define heuristic_hpp

#include <stdio.h>
void heuristic(bool);
#endif /* heuristic_hpp */

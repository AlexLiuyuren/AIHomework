//
//  dfs.hpp
//  AIhomework1
//
//  Created by 刘驭壬 on 2017/10/7.
//  Copyright © 2017年 刘驭壬. All rights reserved.
//

#ifndef dfs_hpp
#define dfs_hpp

#include <stdio.h>
#include "component.hpp"
void dfs();

#endif /* dfs_hpp */

//
//  bfs.hpp
//  AIhomework1
//
//  Created by 刘驭壬 on 2017/10/9.
//  Copyright © 2017年 刘驭壬. All rights reserved.
//

#ifndef bfs_hpp
#define bfs_hpp

#include <stdio.h>
#include "string.h"

void bfs();
#endif /* bfs_hpp */

